<!DOCTYPE html>
<html>
	<head>
		<title>inicio</title>
		<meta charset="utf-8"/>
		<link rel="stylesheet" type="text/css" href="css/Style.css">
	</head>
	<body>
	<center><h1> VARIABLES </h1></center>
	<div id="encabezado">
    <div id="menu">
	<ul>
	 <li><a href="ejercicio1.php"> Operaciones</a><li>
	 <li><a href="ejercicio2.php"> Tabla 1</a></li>
	 <li><a href="ejercicio3.php"> Tabla 2</a></li>
	 <li><a href="ejercicio4.php"> Mayor 1</a></li>
	 <li><a href="ejercicio5.php"> Mayor 2</a></li>
	</ul>
	
	</div>
	</div>
	<P> En álgebra, una operación es la aplicación de un operador sobre los elementos de un conjunto. El operador toma los elementos iniciales y los relaciona con otro elemento de un conjunto final que puede ser de la misma naturaleza o no; esto se conoce técnicamente como ley de composición.
En aritmética y cálculo el conjunto de partida puede estar formado por elementos de un único tipo (las operaciones aritméticas actúan sólo sobre números) o de varios (el producto de un vector por un escalar engloba al conjunto unión de vectores y escalares que conforman un espacio vectorial).
Dependiendo de cómo sean los conjuntos implicados en la operación con respecto al conjunto considerado principal según nuestras intenciones podemos clasificar las operaciones en dos tipos: internas y externas.<BR>

En Matemática conocemos operaciones de suma, resta, multiplicación y división, ya sea con números enteros o fraccionarios, donde se obtiene un nuevo elemento a partir de dos elementos dados. Existen operaciones aritméticas directas o de composición, como la suma, la multiplicación y la potenciación, y las operaciones inversas a ellas, que son la resta, la división, la radicación y la logaritmación.
</P>
	<div class="piepagina">
<center><p>Marvin Otoniel Zamorano Ramirez</p></center>  
</div>
	</body>
	</html>